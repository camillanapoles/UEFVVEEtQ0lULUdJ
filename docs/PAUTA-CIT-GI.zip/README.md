# PAUTA-CIT-GI

Pauta interativa de reunião — Negociação do contrato CIT AI TECH (Camilla Nápoles).

## Princípios desta versão (v4.0)

- **Âncora 50% sempre.** Não 33%, não "1/3", não "Lei 10.973". O contrato deles já oferece 50% na Cl. 3.1 — você só está mantendo essa âncora em todas as dimensões (PI, receitas, custos).
- **Apenas duas categorias de projeto**: B (compartilhado, default 50/50) e D (independente seu, 100% seu, fora do contrato).
- **Proteção por consentimento mútuo**, não por piso legal: qualquer alteração da 50/50 requer "justificativa técnica E financeira válida documentada + consentimento mútuo escrito".

## Estrutura

```
6 blocos · 14 perguntas
├── Bloco 0 — Estrutura da Relação      (1 pergunta)
├── Bloco 1 — PI, Receitas & Custos      (3 perguntas)
├── Bloco 2 — Propriedade Intelectual    (3 perguntas)
├── Bloco 3 — Riscos & Proteções         (2 perguntas)
├── Bloco 4 — Infraestrutura & Logística (2 perguntas)
└── Bloco 5 — Operacional                (3 perguntas)
```

## Funcionalidades

- 5 opções de resposta por pergunta (Ideal · Alternativa · Aceitável · Advogada · Outro)
- Persistência local (localStorage)
- Criptografia opcional via senha (AES-GCM, Web Crypto API)
- Export JSON pra advogada
- Deploy automático via GitHub Actions
- Acesso opcional protegido por token (hash SHA-256)

## Rodar local

```bash
npm install
npm run dev
```

## Publicar no GitHub Pages

1. Criar repo, push:
```bash
git init && git add . && git commit -m "PAUTA-CIT-GI v4"
git branch -M main
git remote add origin git@github.com:USUARIO/pauta-cit-gi.git
git push -u origin main
```

2. **Settings → Pages → Source: GitHub Actions**

3. (Opcional) **Settings → Secrets → Actions → New secret**
   - `APP_ACCESS_TOKEN` = sua senha de acesso

URL final: `https://USUARIO.github.io/pauta-cit-gi/`

## Estrutura de arquivos

```
pauta-cit-gi/
├── .github/workflows/deploy.yml
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   ├── index.css
│   └── lib/
│       ├── data.js       # Perguntas + categorias B e D
│       ├── storage.js    # localStorage + AES
│       └── access.js     # Gate por token
├── index.html
├── package.json
├── tailwind.config.js
├── postcss.config.js
├── vite.config.js
└── .gitignore
```
