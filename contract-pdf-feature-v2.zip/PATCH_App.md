# Patch para `src/App.jsx` (v2 — versão jurídica formal)

> **OBJETIVO:** Gerar contrato consolidado que advogada apenas valide
> (não precise reescrever). Texto novo segue estilo jurídico formal
> idêntico ao original. Anexos completos. Bloco "Dúvida + Sugestão"
> em itálico para pontos onde foi escolhida opção lawyer.

Aplique estas 4 mudanças no `App.jsx` do repo. Tudo o resto fica igual.

---

## 1. Adicionar imports no topo

Localize a linha:

```jsx
import { saveAnswers, loadAnswers, clearAnswers, exportAnswersAsJson, exportAnswersAsPdf } from "./lib/storage";
```

Logo abaixo, adicione:

```jsx
import ContractPreview from "./components/ContractPreview";
import { exportContractAsPdf } from "./lib/contractExport";
import { FileSignature } from "lucide-react";
```

---

## 2. Adicionar estado para a view "contrato" dentro de `MainApp`

Localize:

```jsx
const [view, setView] = useState("mindmap");
```

Substitua os modos do `view` (`"mindmap" | "block"`) para incluir `"contract"`. Nada precisa mudar nessa linha em si — o estado é uma string, basta usar.

---

## 3. Adicionar handler e botão no header

Localize o handler:

```jsx
const handleExportPdf = () => exportAnswersAsPdf(answers, QUESTIONS, BLOCKS);
```

Logo abaixo, adicione:

```jsx
const handleViewContract = () => setView("contract");
const handleContractPdf = () => exportContractAsPdf("contract-preview");
```

Localize o bloco de botões do header (procure `handleExportPdf` ou `<FileDown size={14}`). Logo ANTES do botão "PDF" existente, insira:

```jsx
<button
  onClick={handleViewContract}
  disabled={completedCount === 0}
  className="text-xs font-medium px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed text-white transition-colors flex items-center gap-1.5"
  title="Visualizar contrato consolidado"
>
  <FileSignature size={14} /> <span className="hidden sm:inline">Contrato</span>
</button>
```

---

## 4. Adicionar a view "contract" no `<main>`

Localize:

```jsx
<main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
  {view === "mindmap" && <MindMap onOpenBlock={openBlock} answers={answers} total={totalQuestions} />}
  {view === "block" && activeBlock && <BlockView block={BLOCKS[activeBlock]} onOpenQuestion={openQuestion} answers={answers} />}
</main>
```

Adicione um terceiro caso:

```jsx
<main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
  {view === "mindmap" && <MindMap onOpenBlock={openBlock} answers={answers} total={totalQuestions} />}
  {view === "block" && activeBlock && <BlockView block={BLOCKS[activeBlock]} onOpenQuestion={openQuestion} answers={answers} />}

  {view === "contract" && (
    <div>
      <div className="mb-6 flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-xl sm:text-2xl font-semibold tracking-tight">Contrato Consolidado</h2>
          <p className="text-xs text-slate-500">Versão com decisões da reunião aplicadas. Clique em "Baixar PDF" para gerar o documento.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setView("mindmap")}
            className="text-xs font-medium px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
          >
            ← Voltar
          </button>
          <button
            onClick={handleContractPdf}
            className="text-xs font-medium px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors flex items-center gap-1.5"
          >
            <FileSignature size={14} /> Baixar PDF
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <ContractPreview answers={answers} questions={QUESTIONS} />
      </div>
    </div>
  )}
</main>
```

---

## 5. Adicionar dependência `html2canvas`

No `package.json`, na seção `"dependencies"`, adicione:

```json
"html2canvas": "^1.4.1",
```

Em seguida:

```bash
npm install
```

---

## Pronto

- O botão **"Contrato"** (verde) abre o preview consolidado
- O botão **"Baixar PDF"** dentro do preview gera o documento com diff visual

### Cores aplicadas

- **Cinza claro (referência)** = texto original mantido
- **Azul escuro sobre azul claro** = aceito (sugerida) — substituições, adições, anexos
- **Cinza claro tachado** = texto substituído (riscado)
- **Amarelo** = pendente edição (texto livre da Camilla)
- **Laranja terra** = bloco Dúvida + Sugestão em itálico (lawyer)

### O que entra no PDF final

Quando a Camilla clica em "Baixar PDF":

1. **Cabeçalho** com Recife/PE + data atual
2. **Partes qualificadas** (CONTRATANTE + CONTRATADA)
3. **Cláusulas 1 a 7** com:
   - Texto original riscado quando substituído
   - Nova redação azul abaixo (linguagem jurídica formal)
   - Adições intercaladas (3.5.1, 3.5.2, 3.6, etc.)
   - Aditivos §único quando alternativa aceita
   - Bloco "Dúvida + Sugestão" itálico nos pontos lawyer
   - Notas pendentes amarelas nos pontos open
4. **ANEXOS** (Anexo I: Tabela A/B + Anexo II: Baseline) com texto formal completo
5. **Assinaturas** com local/data e linhas para CONTRATANTE, CONTRATADA e 2 testemunhas

A advogada recebe um PDF que ela só precisa **validar e ajustar pontuais**, não reescrever do zero.
